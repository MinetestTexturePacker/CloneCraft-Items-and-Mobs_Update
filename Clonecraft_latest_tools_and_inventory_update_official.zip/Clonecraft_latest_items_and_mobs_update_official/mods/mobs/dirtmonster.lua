
-- Dirt Monster by PilzAdam



mobs:register_mob("mobs:zombie", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "mobs_zombie.x",
	textures = {"mobs_zombie.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "mobs:cooked_rat",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "default:steel_ingot",
		chance = 20,
		min = 1,
		max = 2,},
		{name = "default:gold_ingot",
		chance = 2,
		min = 0,
		max = 1,},
	},
	armor = 150,
--	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,		speed_run = 15,
		stand_start = 0,		stand_end = 14,
		walk_start = 15,		walk_end = 38,
		run_start = 40,			run_end = 63,
		punch_start = 40,		punch_end = 63,
	},
	allience = "zombie",
	sounds = {
		random = "mobs_zombie",
	},
})
mobs:register_egg("mobs:zombie", "Spawn Zombie", "default_dirt.png", 1)

mobs:register_spawn("mobs:zombie", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)
