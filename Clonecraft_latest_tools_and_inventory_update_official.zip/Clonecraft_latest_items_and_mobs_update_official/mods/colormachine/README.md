If any menu shows something unexpected, please go to another menu page
and come back from there. This ought to update the first menu page.

depends on: dye

supports:
unifieddyes
coloredwood
unifiedbricks
stained_glass
cotton
wool
flags
blox

