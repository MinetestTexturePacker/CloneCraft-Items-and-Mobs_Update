Ghost for Creatures MOB-Engine
==============================
Copyright (c) 2015-2016 BlockMen <blockmen2015@gmail.com>

Version: 2.0 Beta


Adds ghosts to Minetest (requires Creatures MOB-Engine).
Ghosts only spawn at night-time and not underground.
They are flying in the world and attack you players if they notice them.
Ghosts have 12 HP and don't drop any items atm.


License: 
~~~~~~~~
Code:
(c) Copyright 2015-2016 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Media(sounds, textures and meshes/models):
(c) Copyright (2014-2016) BlockMen; CC-BY-SA 3.0


Github:
~~~~~~~
https://github.com/BlockMen/cme/ghost
