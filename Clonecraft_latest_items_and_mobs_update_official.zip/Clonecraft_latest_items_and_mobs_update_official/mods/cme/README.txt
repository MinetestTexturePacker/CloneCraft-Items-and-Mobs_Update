Mod/Modpack Creatures
=====================
Copyright (c) 2015-2016 BlockMen <blockmen2015@gmail.com>

Version: 2.3.1


A Mod(pack) for Minetest that provides a MOB-Engine and adds several creatures to the game.
Currently included: Ghosts, Zombies, Sheep, Chicken and Oerrki.


License: 
~~~~~~~~
Code(if not stated differently):
(c) Copyright 2015-2016 BlockMen; modified zlib-License
see "LICENSE.txt" for details.

Media(if not stated differently):
(c) Copyright (2014-2016) BlockMen; CC-BY-SA 3.0

see each MOB-Module for detailed informations.


Github:
~~~~~~~
https://github.com/BlockMen/cme


Forum:
~~~~~~
https://forum.minetest.net/viewtopic.php?id=8638


Changelog:
~~~~~~~~~~
see Changelog.txt
