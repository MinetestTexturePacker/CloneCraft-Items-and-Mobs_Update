Minetest mod "Bone"
=======================
version: 0.3

License of source code and textures:
------------------------------------
Written 2013 by BlockMen

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


tree_generation based on PilzAdam's farming mod





--USING the mod--

This mod "forces" dirt to drop Bones randomly with rarity = 50 (2%)

The bones can be crafted to bonemeal, which lets grow grass and flowers (remind that flowers are only
in survival and build games are useable).

Furthermore it lets trees grow instantly and supports PilzAdam's farming mod. The wheat, cotton and pumpkin need
a random number of bonemeal to get full grown.